/*
  secrets.h - your networks and passwords (format: secrets_example.h).
  Listed in .gitignore: never commit this file.
  These are the values that were in wifi_logic.cpp before the restructure.
*/
#pragma once

#define WIFI_PROFILES \
  { "shanjing",   "",           "wdwdawdawdwad" },   /* home */             \
  { "SchoolWiFi", "your-login", "your-password" },   /* school: change these */
